
using System.Collections.Generic;
using System.Net.NetworkInformation;
using Unity.Mathematics;
using Random = UnityEngine.Random;
using UnityEngine;
using static UnityEditor.PlayerSettings;
using System;

public class Map
{
    public Color[] colorMap { get; private set; }
    public Dictionary<int,FractionSettings> fractionSettings { get; private set; }
    public List<Point> inactivePoints { get; private set; }
    public List<Point> activePoints { get; private set; }
    private List<Point> pointsToRemove;
    private List<Point> pointsToAdd;

    public bool4[] validDirMap { get; private set; }
    public PointReferenceArray[] pointReferences { get; private set; }


    public int[] ids { get; private set; }

    // points zentral here. with id. id-settings dictionary. events

    private int size;
    private Resolution resolution;



    public void Initialize(Dictionary<int, FractionSettings> fractionSettings)
    {
        resolution = GameModel.Instance.resolution;
        size = resolution.width * resolution.height;

        activePoints = new List<Point>();
        inactivePoints = new List<Point>();
        pointsToRemove = new List<Point>();
        pointsToAdd = new List<Point>();

        Color initColor = new Color(0, 0, 0, 0);
        int idEmpty = 0;
        bool[] initCanExpand = new bool[4] { true, true, true, true };
        

        colorMap = new Color[size];
        ids = new int[size];
        pointReferences = new PointReferenceArray[size];
        for (int i = 0; i < size; i++)
        {
            colorMap[i] = initColor;
            ids[i] = idEmpty;
            pointReferences[i] = new PointReferenceArray();
        }

        InitializeValidDirMap();
        
        this.fractionSettings = fractionSettings;

        GenerateStartPositions();
    }

    private void GenerateStartPositions()
    {
        for(int i = 1; i <= fractionSettings.Count; i++)
        {
            AddPoint(i, fractionSettings[i].StartPosition);
        }
        foreach(Point point in pointsToAdd)
        {
            activePoints.Add(point);
        }
    }

    public void Update()
    {
        Debug.Log("active point count: " + activePoints.Count);
        Debug.Log("inactive point count: " + inactivePoints.Count);

        pointsToRemove = new List<Point>();
        pointsToAdd = new List<Point>();
        foreach (Point point in activePoints)
        {
            Vector2Int position = point.position;
            int index = GetPositionIndex(position);
            bool4 canExpand = validDirMap[index];
            int fractionId = point.fractionId;

            for (int direction = 0; direction < 4; direction++)
            {
                if (canExpand[direction] && Random.Range(0f, 1f) < fractionSettings[fractionId].ExpansionRate)
                {
                    AddPoint(fractionId, CalculateNewPosition(position, direction));
                }
            }
        }

        foreach (Point point in pointsToRemove)
        {
            activePoints.Remove(point);
        }
        foreach(Point point in pointsToAdd)
        {
            activePoints.Add(point);
        }
    }

    public void UpdateState()
    {
        
    }

    private void AddPoint(int id, Vector2Int position)
    {
        int index = GetPositionIndex(position);
        ids[index] = id;
        this.colorMap[index] = fractionSettings[id].Color;
        Point point = new Point(position, id);
        if (IsInactiveNow(index))
        {
            inactivePoints.Add(point);
        }
        else
        {
            pointsToAdd.Add(point);
        }


        Vector2Int checkPos;
        int checkIndex;

        checkPos = new Vector2Int(position.x, position.y + 1);
        if (checkPos.y <= resolution.height)
        {
            checkIndex = GetPositionIndex(checkPos);
            pointReferences[checkIndex].bottom = point;
            UpdateValidDir(checkIndex, 2, false);
            if (IsInactiveNow(checkIndex) && pointReferences[index].top != null)
            {
                inactivePoints.Add(pointReferences[index].top);
                pointsToRemove.Add(pointReferences[index].top);
            }
        }
        checkPos = new Vector2Int(position.x, position.y - 1);
        if (checkPos.y > 0)
        {
            checkIndex = GetPositionIndex(checkPos);
            pointReferences[checkIndex].top = point;
            UpdateValidDir(checkIndex, 0, false);
            if (IsInactiveNow(checkIndex) && pointReferences[index].bottom != null)
            {
                inactivePoints.Add(pointReferences[index].bottom);
                pointsToRemove.Add(pointReferences[index].bottom);
            }
        }
        checkPos = new Vector2Int(position.x + 1, position.y);
        if (checkPos.x <= resolution.width)
        {
            checkIndex = GetPositionIndex(checkPos);
            pointReferences[checkIndex].left = point;
            UpdateValidDir(checkIndex, 3, false);
            if (IsInactiveNow(checkIndex) && pointReferences[index].right != null)
            {
                inactivePoints.Add(pointReferences[index].right);
                pointsToRemove.Add(pointReferences[index].right);
            }
        }
        checkPos = new Vector2Int(position.x - 1, position.y);
        if (checkPos.x > 0)
        {
            checkIndex = GetPositionIndex(checkPos);
            pointReferences[checkIndex].right = point;
            UpdateValidDir(checkIndex, 1, false);
            if (IsInactiveNow(checkIndex) && pointReferences[index].left != null)
            {
                inactivePoints.Add(pointReferences[index].left);
                pointsToRemove.Add(pointReferences[index].left);
            }
        }
    }

    private Vector2Int CalculateNewPosition(Vector2Int oldPos, int dirIndex)
    {
        Vector2Int newPos;

        switch (dirIndex)
        {
            case 0:
                newPos = new Vector2Int(oldPos.x, oldPos.y + 1);
                break;
            case 1:
                newPos = new Vector2Int(oldPos.x + 1, oldPos.y);
                break;
            case 2:
                newPos = new Vector2Int(oldPos.x, oldPos.y - 1);
                break;
            case 3:
                newPos = new Vector2Int(oldPos.x - 1, oldPos.y);
                break;
            default:
                newPos = new Vector2Int(0, 0);
                break;
        }
        return newPos;
    }

    private void UpdateValidDir(int index, int direction, bool value)
    {
        validDirMap[index][direction] = value;
    }

    private bool IsInactiveNow(int index)
    {
        bool4 canExpand = validDirMap[index];
        if (canExpand[0] == true) { return false; }
        else if (canExpand[1] == true) { return false; }
        else if (canExpand[2] == true) { return false; }
        else if (canExpand[3] == true) { return false; }
        return true;
    }

    private void InitializeValidDirMap()
    {
        validDirMap = new bool4[size];
        bool4 initValue = new bool4(true,true,true,true);

        for (int i = 0; i < size; i++)
        {
            if(i == 0) { validDirMap[i] = new bool4(true, true, false, false); }
            else if(i == resolution.width - 1) { validDirMap[i] = new bool4(true, false, false, true); }
            else if(i == (resolution.height - 1) * resolution.width) { validDirMap[i] = new bool4(false, true, true, false); }
            else if (i == (size - 1) * resolution.width) { validDirMap[i] = new bool4(false, false, true, true); }

            else if(i >= 1 && i < resolution.width - 1) { validDirMap[i] = new bool4(true, true, false, true); }
            else if (i >= (resolution.height - 1) * resolution.width + 1 && i < size - 1) { validDirMap[i] = new bool4(false, true, true, true); }
            else if (i % resolution.width == 0) { validDirMap[i] = new bool4(true, true, true, false); }
            else if(i % resolution.width == (resolution.width-1)/resolution.width) { validDirMap[i] = new bool4(true, false, true, true); }
            else { validDirMap[i] = initValue; }
        }

        //validDirMap[0] = new bool4(true,true,false,false);
        //validDirMap[resolution.width-1] = new bool4(true, false, false, true);
        //validDirMap[(resolution.height-1)*resolution.width] = new bool4(false, true, true, false);
        //validDirMap[size-1] = new bool4(false, false, true, true);

        //for (int i = 1; i < resolution.width-1; i++)
        //{
        //    validDirMap[i] = new bool4(true,true,false,true);
        //}
        //for (int i = (resolution.height - 1) * resolution.width+1; i < size - 1; i++)
        //{
        //    validDirMap[i] = new bool4(false, true, true, true);
        //}
        //for (int i = resolution.width; i < (resolution.height - 1) * resolution.width; i += resolution.width)
        //{
        //    validDirMap[i] = new bool4(true, true, true, false);
        //}
        //for (int i = resolution.width-1 + resolution.width; i < size-1; i += resolution.width)
        //{
        //    validDirMap[i] = new bool4(true, false, true, true);
        //}
    }

    public int GetPositionIndex(Vector2Int position)
    {
        return resolution.width*(position.y-1) + position.x - 1;
    }

    private bool IsPositionValid(Vector2Int position)
    {
        if (position.x < 1) { return false; }
        else if (position.y < 1) {  return false; }
        else if (position.x > resolution.width) { return false; }
        else if (position.y > resolution.height) {  return false; }
        return true;
    }
}

public class PointReferenceArray
{
    public Point top;
    public Point right;
    public Point bottom;
    public Point left;
}
