using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor;
using UnityEditor.U2D.Aseprite;
using UnityEngine;
using UnityEngine.UI;

public class Game : MonoBehaviour
{
    Controller controller;
    [SerializeField]
    List<FractionSettings> fractionSettings;
    float time;
    float updateTime;

    private void Awake()
    {
        Initialize();
        time = 0;
        updateTime = 0.1f;
    }


    void Start()
    {
    }

    void Update()
    {
        GameModel.Instance.Update();

        //time += Time.deltaTime;
        //if (time > updateTime)
        //{
        //    GameModel.Instance.Update();
        //    time = 0;
        //    updateTime = 0.1f;
        //}
    }

    private void Initialize()
    {
        GameModel.Instance.Initialize(fractionSettings);

        controller = this.AddComponent<Controller>();
        controller.Initialize();

        Debug.Log("Game initialized.");
    }

    
}
